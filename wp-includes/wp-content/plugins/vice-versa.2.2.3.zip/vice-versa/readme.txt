=== Vice Versa ===

Contributors: Jason Lau
Donate link: http://jasonlau.biz
Tags: post, page, type, kind, convert, converts, converter, convertr, revert, turn, into, to, make, change, swap, category, categories, parent, parents, manage, vice, vise, versa, jason, lau, jasonlau, jasonlau.biz
Requires at least: 2.8.4 
Stable tag: 2.2.3
Tested up to: 3.4.1

== Description ==

Vice Versa vice versa vice-versa viceversa can easily convert WordPress Posts to Pages and Pages to Posts. You can also assign a Page or Post a parent or category(s) as you are converting from one to the other. Vice Versa is easy to install and use. No database tables are affected during installation and there are no additional settings required. Vice versa also has some premium modules to extend it's functionality. Premium modules include, Category to Category, Category to Post Type, and Post to Post Type conversions.

== Installation ==

*Use the Plugin installer which is located in the WordPress Dashboard menu under "Plugins > Add New". OR ...
*Download Vice Versa.
*Unzip vice-versa.zip. 
*Upload the folder named 'vice-versa' to the wp-content/plugins directory on your server
*Go to the plugins manager in your Wordpress Dashboard and locate Vice Versa in the list of plugins (under 'V' for 'Vice Versa').
*Click Activate.  

Once the plugin is activated, you will find Vice Versa in the Dashboard menu under "Tools".

== Frequently Asked Questions ==

= What premium modules are available, and where can I download them? =
Vice versa has some premium modules to extend it's functionality. Premium modules include, Category to Category, Category to Post Type, and Post to Post Type conversions. The premium modules can be purchased from my website at http://jasonlau.biz/home/membership-options

= Do you accept donations? =
Yes I do. Thank you in advance!

== Screenshots ==

1. screenshot-1.png Is a picture of the Vice Versa Admin panel.
   
== Changelog ==

= 1.0 =
Initial release.

= 2.0.0 =
Total recode. Fixed a bug or two. Changed the appearance to be more in keeping with the Dashboard. Moved it to Tools instead of Settings.

= 2.1.0 =
Prayers have been answered. Added the option to convert multiple pages or posts.

= 2.1.1 =
Added paging and additional sorting. Verified compatibility with WordPress 3.0.5.

= 2.1.2 =
Verified compatibility with WordPress 3.0.6.

= 2.1.3 =
Fixed a minor bug. Verified compatibility with WordPress 3.1.0.

= 2.1.4 =
Total rebuild and redesign.

= 2.1.5 =
Limited the length of select menu labels to 25 characters and added the full label to the tooltip. A few minor changes.

= 2.1.6 =
Added search field.

= 2.1.7 =
Critical update. Fixes a few bugs including one which caused a 404 error when using certain permalink structures.

= 2.1.8 =
Corrects a bug in the table sorting and some CSS bugs.

= 2.1.9 =
Critical update. Fixes a bug which may have caused excessive server load during conversion.

= 2.1.9.2 =
Cleaned some development code from the source to remove some extra character output.

= 2.2.0 =
Major changes to the backend. Vice Versa now uses modules for each conversion tool type. Vice Versa includes 2 free modules for Post to Page and Page to Post conversion. Additional premium modules are now available which expand Vice Versa's conversion-type capabilities. Premium modules are available at JasonLau.biz

= 2.2.1 =
Changed the Test Mode controller, which fixed a bug in it.

= 2.2.2 =
Restructured alot of code and fixed a few bugs. Verified compatibility with WordPress 3.4.1

= 2.2.3 =
Fixed a pagination bug in the post2page module.

== Upgrade Notice ==

= 1.0 =
Initial release.

= 2.0.0 =
Total recode. Fixed a bug or two. Changed the appearance to be more in keeping with the Dashboard. Moved it to Tools instead of Settings.

= 2.1.0 =
Prayers have been answered. Added the option to convert multiple pages or posts.

= 2.1.1 =
Added paging and additional sorting. Verified compatibility with WordPress 3.0.5.

= 2.1.2 =
Verified compatibility with WordPress 3.0.6.

= 2.1.3 =
Fixed a minor bug. Verified compatibility with WordPress 3.1.0.

= 2.1.4 =
Total rebuild and redesign.

= 2.1.5 =
Limited the length of select menu labels to 25 characters and added the full label to the tooltip. A few minor changes.

= 2.1.6 =
Added search field.

= 2.1.7 =
Critical update. Fixes a few bugs including one which caused a 404 error when using certain permalink structures.

= 2.1.8 =
Corrects a bug in the table sorting and some CSS bugs.

= 2.1.9 =
Critical update. Fixes a bug which may have caused excessive server load during conversion.

= 2.1.9.2 =
Cleaned some development code from the source to remove some extra character output.

= 2.2.0 =
Major changes to the backend. Vice Versa now uses modules for each conversion tool type. Vice Versa includes 2 free modules for Post to Page and Page to Post conversion. Additional premium modules are now available which expand Vice Versa's conversion-type capabilities. Premium modules are available at JasonLau.biz

= 2.2.1 =
Changed the Test Mode controller, which fixed a bug in it.

= 2.2.2 =
Restructured alot of code and fixed a few bugs. Verified compatibility with WordPress 3.4.1

= 2.2.3 =
Fixed a pagination bug in the post2page module.